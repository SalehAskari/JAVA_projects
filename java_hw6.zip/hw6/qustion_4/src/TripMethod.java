public interface TripMethod {
	public int calcPrice(TripParam params);

}
