public class Jacket extends Clothing {

	public Jacket(String name, Season season, long basePrice) {
		super(name, season, basePrice);
	}

}
