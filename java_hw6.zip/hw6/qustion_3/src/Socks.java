public class Socks extends Clothing {

	public Socks(String name, Season season, long basePrice) {
		super(name, season, basePrice);
	}

}
