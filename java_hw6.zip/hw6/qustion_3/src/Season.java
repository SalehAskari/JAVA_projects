public enum Season {

	SPRING, SUMMER, FALL, WINTER
	
}
