public interface DiscountStrategy {
    long priceByDiscount(Clothing clothing);
}
