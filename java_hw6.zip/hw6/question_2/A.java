public class A{


    public String method1(){
        return "A1";
    }

    public String method2(){
        return "A2";
    }

}