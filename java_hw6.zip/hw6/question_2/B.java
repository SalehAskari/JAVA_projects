public class B extends A {
    
    public String method2(){
        return method1()+"B2";
    }
}
