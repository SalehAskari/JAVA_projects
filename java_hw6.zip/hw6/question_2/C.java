public class C extends B {
    

    public String method1(){
        return "C1";
    }
}
